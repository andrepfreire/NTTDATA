const boarTitle = '.js-board-editing-target';

export default class Board {
    
    static get boarTitle() {
        return boarTitle;
    }
}