const root = '/';
const leftMenuItem = 'span';
export default class Navigation {

    static get root() {
        return root;
    }
    
    static get leftMenuItem() {
        return leftMenuItem;
    }
}