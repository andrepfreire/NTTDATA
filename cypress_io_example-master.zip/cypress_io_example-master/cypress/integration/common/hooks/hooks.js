beforeEach('Login to the system', () => {
    cy.login('defaultUser');
});